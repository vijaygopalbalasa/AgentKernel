# Agent OS — Android for AI Agents

## What This Project Is
Agent OS is an operating system for AI agents — the same way Android is an OS for phone apps. It manages agent lifecycle, memory, identity, communication, skills, and permissions. Agents are first-class citizens, not humans.

## Architecture (5 Layers — mirrors Android)

```
Layer 5: Agent Applications  (= Android Apps)       → Actual agents that run on the OS
Layer 4: Agent Framework     (= App Framework)       → Identity, Memory, Skills, Comms, Permissions APIs
Layer 3: Agent Runtime       (= ART)                 → Lifecycle, sandboxing, scheduling, state
Layer 2: Model Abstraction   (= HAL)                 → Provider adapters (Claude/GPT/Gemini/Llama)
Layer 1: Compute Kernel      (= Linux Kernel)         → Process mgmt, storage, network, security
```

## Core Protocols (we build ON these, never reinvent)
- **MCP (Model Context Protocol)** by Anthropic — how agents connect to tools and data ("USB-C for AI")
- **A2A (Agent-to-Agent Protocol)** by Google — how agents discover and talk to each other ("WiFi for AI")

## Tech Stack
- **Language:** TypeScript (everything). Same as OpenClaw (117K stars).
- **Runtime:** Node.js 22+
- **Package Manager:** pnpm with workspaces (monorepo)
- **Database:** PostgreSQL (structured) + Qdrant (vector/memory) + Redis (pub/sub, cache)
- **Testing:** Vitest with V8 coverage
- **Build:** tsup or tsdown
- **Linting:** Biome (fast, replaces ESLint + Prettier)
- **Config:** YAML for user config, JSON for internal

## Monorepo Structure
```
agent-os/
├── packages/
│   ├── kernel/              # L1: Compute Kernel
│   ├── mal/                 # L2: Model Abstraction Layer
│   ├── runtime/             # L3: Agent Runtime
│   ├── framework/           # L4: Agent Framework
│   │   ├── identity/
│   │   ├── memory/
│   │   ├── skills/
│   │   ├── communication/
│   │   ├── tools/
│   │   ├── permissions/
│   │   └── events/
│   ├── sdk/                 # What developers import to build agents
│   └── shared/              # Shared types, utils, constants
├── apps/
│   ├── gateway/             # The main daemon process (like OpenClaw's gateway)
│   ├── cli/                 # CLI: agent-os init, start, deploy
│   └── dashboard/           # Web UI for monitoring
├── agents/                  # Example agents
│   ├── assistant/
│   ├── coder/
│   └── system/
├── providers/               # LLM provider adapters
│   ├── anthropic/
│   ├── openai/
│   ├── google/
│   └── ollama/
└── skills/                  # Built-in skills
```

## Design Principles
1. **Agents are processes** — like apps on Android. Each has its own memory, permissions, lifecycle.
2. **Model-agnostic** — the MAL (Model Abstraction Layer) means ANY LLM works. Never lock to one provider.
3. **Protocol-native** — MCP for tools, A2A for agent-to-agent. No custom protocols.
4. **Self-hostable** — runs on any machine. Not a SaaS. Open source MIT.
5. **Memory is first-class** — episodic, semantic, procedural memory that persists across restarts.
6. **Skills are installable** — like Android apps. Agents gain capabilities by installing skills.
7. **Security by default** — sandboxing, capability-based permissions, prompt injection defense.

## Coding Standards
- All code is TypeScript with strict mode
- Use `interface` over `type` for public APIs
- Use Zod for runtime validation of all external inputs
- Every package exports from a single `index.ts` barrel file
- Error handling: use Result types (neverthrow), not try/catch for business logic
- Naming: PascalCase for types/interfaces, camelCase for functions/variables, SCREAMING_SNAKE for constants
- All async functions must handle errors explicitly
- Every public function needs JSDoc comments
- Tests colocated with source: `foo.ts` → `foo.test.ts`

## What NOT To Do
- ❌ No blockchain, no Web3, no tokens, no Solana — this is pure AI infrastructure
- ❌ No custom protocols — use MCP and A2A
- ❌ No class inheritance — prefer composition and interfaces
- ❌ No `any` type — ever
- ❌ No default exports — always named exports
- ❌ No console.log in library code — use the structured logger from @agent-os/kernel

## Key Inspiration
- **OpenClaw** (117K ⭐) — gateway architecture, skills system, MCP integration, persistent memory
- **Moltbook** — API-first agent interaction, emergent behavior, agent-managed platform
- **Android AOSP** — layered architecture, HAL abstraction, permission system, app lifecycle

## Current Phase
Phase 1: Foundation — building Kernel + MAL + basic Runtime
Goal: Get a single agent spawned, connected to Claude, and responding to messages
